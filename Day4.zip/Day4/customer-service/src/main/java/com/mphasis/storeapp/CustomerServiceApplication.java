package com.mphasis.storeapp;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.client.ServiceInstance;
import org.springframework.cloud.client.discovery.DiscoveryClient;
import org.springframework.cloud.netflix.eureka.EnableEurekaClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

@EnableEurekaClient
@RestController
@SpringBootApplication
public class CustomerServiceApplication {

	@Autowired
	private DiscoveryClient client;
	
	public static void main(String[] args) {
		SpringApplication.run(CustomerServiceApplication.class, args);
	}

	@GetMapping("/get-product-service")
	public String getAllProducts() {
     List<ServiceInstance>	instanceList=client.getInstances("PRODUCT-SERVICE");
	 
     System.out.println("--------------------------------------------");
     System.out.println("---------Product Service MetaData------------");
     System.out.println("--------------------------------------------");
     
     for(ServiceInstance si:instanceList)
     {
    System.out.println("Product Service :");

    System.out.println("Service Id     :"+si.getInstanceId());
    System.out.println("Service Host   :"+si.getHost());
    System.out.println("Service Port   :"+si.getPort());
    System.out.println("Service Uri    :"+si.getUri());
    System.out.println("Service Scheme :"+si.getScheme());
    System.out.println(si.getMetadata());
  	 
     }
	 
	 
     ServiceInstance si=instanceList.get(0);
                
		return si.getUri().toString();
	}
	
	
	@GetMapping("/get-products")
	public String getProducts() {
		
		 List<ServiceInstance>	instanceList=client.getInstances("PRODUCT-SERVICE");
		 ServiceInstance si=instanceList.get(0);
	    
		 RestTemplate restTemplate=new RestTemplate();
	    
		String url=si.getUri().toString()+"/products";
		return restTemplate.getForObject(url, String.class);
	}
	
	@GetMapping("/get-products/{id}")
	public String getProductById(@PathVariable("id") int id) {
		
		 List<ServiceInstance>	instanceList=client.getInstances("PRODUCT-SERVICE");
		 ServiceInstance si=instanceList.get(0);
	    
		 RestTemplate restTemplate=new RestTemplate();
	    
		String url=si.getUri().toString()+"/products/"+id;
		return restTemplate.getForObject(url,String.class);
		}
	
}
