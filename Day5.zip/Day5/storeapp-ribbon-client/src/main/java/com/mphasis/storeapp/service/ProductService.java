package com.mphasis.storeapp.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.client.RestTemplate;

import com.mphasis.storeapp.domain.Product;


@Service
public class ProductService {

	@Autowired
	private RestTemplate restTemplate;

	public String getPort() {
		return restTemplate.getForObject("http://product-service/products/get-port", String.class);
	}

	public String getProducts() {
		return restTemplate.getForObject("http://product-service/products", String.class);
	}

	public Product getProductById(int id) {
		return restTemplate.getForObject("http://product-service/products/"+id, Product.class);
	}

}
