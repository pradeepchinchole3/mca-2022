package com.mphasis.storeapp.service;

import java.util.List;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import com.mphasis.storeapp.domain.Product;
import com.mphasis.storeapp.fallback.ProductServiceFallback;

@FeignClient(name="product-service",fallback = ProductServiceFallback.class)
public interface ProductServiceProxy {

	@GetMapping("/products/get-port")
	public String getPort();

	@GetMapping(value = "/products", produces = MediaType.APPLICATION_JSON_VALUE)
	public List<Product> getAllProducts();

	@GetMapping("/products/{id}")
	public Product getProductById(@PathVariable("id") Integer productId);

}
