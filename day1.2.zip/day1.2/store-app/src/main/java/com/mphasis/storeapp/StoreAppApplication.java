package com.mphasis.storeapp;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.context.properties.EnableConfigurationProperties;

import com.mphasis.storeapp.dao.IProductRepository;
import com.mphasis.storeapp.domain.Product;


@SpringBootApplication
public class StoreAppApplication implements CommandLineRunner{

	@Autowired
	IProductRepository productRepository;
	
	public static void main(String[] args) {
		SpringApplication.run(StoreAppApplication.class, args);
	}
	
	
	@Override
	public void run(String... args) throws Exception {
		
		productRepository.save(new Product(null, "Oppo 37", 12000.00, "mobile"));
		productRepository.save(new Product(null, "Vivo 57", 12000.00, "mobile"));
		productRepository.save(new Product(null, "Mac 100", 12000.00, "Laptop"));
		productRepository.save(new Product(null, "TV", 12000.00, "elctronics"));
		System.out.println("Inserted the data in db.....");		
	}

}
