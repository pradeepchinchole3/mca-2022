package com.mphasis.storeapp.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import com.mphasis.storeapp.domain.Product;
import com.mphasis.storeapp.service.ProductServiceProxy;

@RestController
public class ProductClientController {

	@Autowired
	ProductServiceProxy productServiceProxy;

	@GetMapping("/get-port")
	public String getPort() {
		return productServiceProxy.getPort();
	}

	@GetMapping("/get-products")
	public List<Product> getProducts() {
		return productServiceProxy.getAllProducts();
	}

	@GetMapping("/get-product/{id}")
	public Product getProductById(@PathVariable("id") int id) {
		return productServiceProxy.getProductById(id);
	}

}
