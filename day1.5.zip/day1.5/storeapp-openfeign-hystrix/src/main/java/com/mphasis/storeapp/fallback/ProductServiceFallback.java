package com.mphasis.storeapp.fallback;

import java.util.Arrays;
import java.util.List;

import org.springframework.stereotype.Service;

import com.mphasis.storeapp.domain.Product;
import com.mphasis.storeapp.service.ProductServiceProxy;

@Service
public class ProductServiceFallback implements ProductServiceProxy{

	@Override
	public String getPort() {
		// TODO Auto-generated method stub
		return "Default Product Service running on port 8080";
	}

	@Override
	public List<Product> getAllProducts() {
		return Arrays.asList(new Product(11111,"Default Product",34444.555,"Default Category"));
		
	}

	@Override
	public Product getProductById(Integer productId) {
		return new Product(1111,"Default Product",2303.33,"Default Category");
		
	}

	
}
