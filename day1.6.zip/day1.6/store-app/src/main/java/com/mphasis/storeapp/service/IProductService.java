package com.mphasis.storeapp.service;

import java.util.List;

import com.mphasis.storeapp.domain.Product;

public interface IProductService {
	
	Product addProduct(Product product);
	Product updateProduct(Product product);
	void deleteProduct(Integer productId);
	Product getProduct(Integer productId);
	List<Product> getAllProducts();
}
