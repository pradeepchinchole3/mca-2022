package com.mphasis.storeapp.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cloud.client.circuitbreaker.EnableCircuitBreaker;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import com.mphasis.storeapp.domain.Product;
import com.mphasis.storeapp.service.ProductService;

import io.github.resilience4j.circuitbreaker.annotation.CircuitBreaker;

@RestController
public class ProductClientController {

	@Autowired
	ProductService productService;

	@GetMapping("/get-port")
	public String getPort() {
		return productService.getPort();
	}

	@GetMapping("/get-products")
	public String getProducts() {
		return productService.getProducts();
	}

	@GetMapping("/get-product/{id}")
	public Product getProductById(@PathVariable("id") int id) {
		return productService.getProductById(id);
	}

	
	
}
