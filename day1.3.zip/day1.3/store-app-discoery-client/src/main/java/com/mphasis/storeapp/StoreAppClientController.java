package com.mphasis.storeapp;

import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cloud.client.ServiceInstance;
import org.springframework.cloud.client.discovery.DiscoveryClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

@RestController
public class StoreAppClientController {

	@Autowired
	private DiscoveryClient client;
	
	private RestTemplate template=new RestTemplate();
	
	
	
	
	
	@GetMapping("/get-product/{id}")
	public String getProductById(@PathVariable("id") int id) {
		
  List<ServiceInstance>	list=client.getInstances("product-service");
		
  for(ServiceInstance si:list)
  {
  System.out.println("Instance Port :"+si.getPort());
  System.out.println("Instance URI  :"+si.getUri());
  System.out.println("Instance URI  :"+si.getUri().toString());
  
  System.out.println("Service Id    :"+si.getServiceId());
  System.out.println(" MAp details :");
  System.out.println(si.getMetadata()); 
  }
   ServiceInstance si=list.get(0);
  
   String productDetails=template.getForObject(si.getUri().toString()+"/products/"+id, String.class);
   
		
    return "Product Details   :"+productDetails;
	}
	
	
	
}
