package com.mphasis.storeapp.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mphasis.storeapp.dao.IProductRepository;
import com.mphasis.storeapp.domain.Product;

@Service
public class ProductServiceImpl implements IProductService {

	@Autowired
	private IProductRepository productRepository;

	@Override
	public Product addProduct(Product product) {

		return productRepository.save(product);

	}

	@Override
	public Product updateProduct(Product product) {

		
		return productRepository.save(product);
	}

	@Override
	public void deleteProduct(Integer productId) {
		
		productRepository.deleteById(productId);
	

	}

	@Override
	public Product getProduct(Integer productId) {
		return productRepository.findById(productId).get();
	}

	@Override
	public List<Product> getAllProducts() {
		return productRepository.findAll();
	}

}
